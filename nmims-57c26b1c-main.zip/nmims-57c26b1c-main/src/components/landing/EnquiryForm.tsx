import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Phone } from "lucide-react";

const schema = z.object({
  name: z.string().trim().min(2, "Enter your full name").max(80),
  email: z.string().trim().email("Enter a valid email").max(120),
  mobile: z.string().trim().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit mobile"),
  city: z.string().trim().min(2, "Enter your city").max(60),
  program: z.string().min(1, "Select a program"),
});

type FormData = z.infer<typeof schema>;

const programs = [
  "Online MBA",
  "Online MCA",
  "Online BBA",
  "Online BCA",
  "Online M.Com",
  "Online B.Com",
  "PG Diploma",
];

export function EnquiryForm({ compact = false }: { compact?: boolean }) {
  const [submitted, setSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (_data: FormData) => {
    await new Promise((r) => setTimeout(r, 700));
    setSubmitted(true);
    reset();
    setTimeout(() => setSubmitted(false), 4500);
  };

  return (
    <div className={`glass-card overflow-hidden rounded-3xl ${compact ? "" : "w-full"}`} id="enquire">
      <div className="bg-[linear-gradient(135deg,#ef4444,#dc2626)] px-6 py-5 text-center text-white sm:px-8">
        <h3 className="text-2xl font-extrabold tracking-tight">Register Now</h3>
        <a href="tel:+917990748485" className="mt-1 inline-flex items-center gap-2 text-sm font-semibold text-white/95 hover:text-white">
          <Phone className="h-4 w-4" /> Call @ 7990748485
        </a>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3 p-6 sm:p-8" noValidate>
        <Field label="Full Name" error={errors.name?.message}>
          <input
            {...register("name")}
            placeholder="Your full name"
            className="input"
            autoComplete="name"
          />
        </Field>
        <Field label="Email" error={errors.email?.message}>
          <input
            type="email"
            {...register("email")}
            placeholder="you@email.com"
            className="input"
            autoComplete="email"
          />
        </Field>
        <Field label="Mobile Number" error={errors.mobile?.message}>
          <div className="flex">
            <span className="inline-flex items-center rounded-l-xl border border-r-0 border-border bg-secondary px-3 text-sm font-semibold text-secondary-foreground">
              +91
            </span>
            <input
              {...register("mobile")}
              placeholder="10-digit mobile"
              className="input rounded-l-none"
              inputMode="numeric"
              maxLength={10}
              autoComplete="tel"
            />
          </div>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="City" error={errors.city?.message}>
            <input {...register("city")} placeholder="Your city" className="input" />
          </Field>
          <Field label="Program" error={errors.program?.message}>
            <select {...register("program")} className="input" defaultValue="">
              <option value="" disabled>Select</option>
              {programs.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </Field>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="mt-2 w-full rounded-xl gradient-primary px-5 py-3.5 text-base font-bold text-primary-foreground shadow-elegant transition-transform hover:scale-[1.02] active:scale-[0.99] disabled:opacity-70"
        >
          {isSubmitting ? "Submitting..." : "Request a Call Back →"}
        </button>
        <p className="text-center text-[11px] text-muted-foreground">
          By submitting, you agree to our T&amp;Cs and Privacy Policy.
        </p>
      </form>

      <AnimatePresence>
        {submitted && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-foreground/50 backdrop-blur-sm p-4"
            onClick={() => setSubmitted(false)}
          >
            <motion.div
              initial={{ scale: 0.85, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9 }}
              className="max-w-md rounded-3xl bg-card p-8 text-center shadow-elegant"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full gradient-primary text-primary-foreground">
                <CheckCircle2 className="h-8 w-8" />
              </div>
              <h4 className="text-2xl font-extrabold text-foreground">Thank you!</h4>
              <p className="mt-2 text-sm text-muted-foreground">
                Your enquiry has been received. Our admission counsellor will reach out within the next 30 minutes.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="mt-6 rounded-xl gradient-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground"
              >
                Continue Exploring
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid var(--color-border);
          background: white;
          padding: 0.7rem 0.9rem;
          font-size: 0.9rem;
          color: var(--color-foreground);
          outline: none;
          transition: border-color .15s, box-shadow .15s;
        }
        .input:focus {
          border-color: var(--color-primary);
          box-shadow: 0 0 0 3px color-mix(in oklab, var(--color-primary) 18%, transparent);
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      {children}
      {error && <span className="mt-1 block text-xs font-medium text-destructive">{error}</span>}
    </label>
  );
}