import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Phone, MessageCircle, GraduationCap, Briefcase, Clock, Award, Users, BookOpen,
  Laptop, Video, Headphones, ChevronDown, MapPin, Mail, Star, ArrowRight,
  TrendingUp, Globe2, Sparkles, ShieldCheck, BarChart3, Building2, Cpu, Megaphone,
  Calculator, UserCog,
} from "lucide-react";
import heroStudent from "@/assets/hero-student.jpg";
import careerImg from "@/assets/career-growth.jpg";
import gCampus from "@/assets/gallery-campus.jpg";
import gClass from "@/assets/gallery-classroom.jpg";
import gEvents from "@/assets/gallery-events.jpg";
import gStudents from "@/assets/gallery-students.jpg";
import gFacilities from "@/assets/gallery-facilities.jpg";
import universityImg from "@/assets/university-building.jpg";
import t1 from "@/assets/testimonial-1.jpg";
import t2 from "@/assets/testimonial-2.jpg";
import t3 from "@/assets/testimonial-3.jpg";
import { EnquiryForm } from "@/components/landing/EnquiryForm";
import { Counter } from "@/components/landing/Counter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Online MBA & Degree Programs | UGC-Entitled Admissions Open 2026" },
      { name: "description", content: "Earn a UGC-entitled online degree from India's top-ranked university. Live classes, placement support & flexible learning. Admissions open — talk to a counsellor today." },
      { property: "og:title", content: "Online Degree Programs — Admissions Open 2026" },
      { property: "og:description", content: "UGC-entitled online MBA, MCA, BBA & more. Live classes, placement support, flexible learning." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "EducationalOrganization",
          name: "EduPrime — Authorised Admission Partner",
          url: "/",
          description: "Authorised admission partner for India's top-ranked online universities.",
          areaServed: "IN",
        }),
      },
    ],
  }),
  component: Index,
});

const PHONE = "+919876543210";
const WA = "919876543210";
const waLink = `https://wa.me/${WA}?text=${encodeURIComponent("Hi, I'd like to know about admissions.")}`;
const telLink = `tel:${PHONE}`;

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Hero />
        <CareerGrowth />
        <Gallery />
        <Programs />
        <Specializations />
        <WhyChoose />
        <Counters />
        <CampusSection />
        <Testimonials />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
      <FloatingWA />
      <MobileCTABar />
    </div>
  );
}

/* ---------- HEADER ---------- */
function Header() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all ${
        scrolled ? "border-b border-border bg-background/90 backdrop-blur-lg shadow-card" : "bg-background/70 backdrop-blur"
      }`}
    >
      <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex min-w-0 items-center gap-3 sm:gap-5">
          <BrandLogo />
          <div className="hidden h-8 w-px bg-border sm:block" />
          <PartnerLogo />
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <a
            href={telLink}
            className="hidden items-center gap-2 rounded-xl border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground shadow-card transition hover:border-primary hover:text-primary sm:inline-flex"
          >
            <Phone className="h-4 w-4" /> Call Now
          </a>
          <a
            href={waLink}
            target="_blank" rel="noopener"
            className="inline-flex items-center gap-2 rounded-xl bg-[color:var(--whatsapp)] px-3 py-2 text-sm font-semibold text-white shadow-card transition hover:opacity-90 sm:px-4"
          >
            <MessageCircle className="h-4 w-4" /> <span className="hidden sm:inline">WhatsApp</span>
          </a>
          <a
            href="#enquire"
            className="hidden rounded-xl gradient-primary px-4 py-2 text-sm font-bold text-primary-foreground shadow-card transition hover:scale-[1.02] md:inline-flex"
          >
            Apply Now
          </a>
        </div>
      </div>
    </header>
  );
}

function BrandLogo() {
  return (
    <a href="/" className="flex min-w-0 items-center gap-2">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl gradient-primary text-primary-foreground shadow-card">
        <GraduationCap className="h-5 w-5" />
      </span>
      <span className="min-w-0">
        <span className="block truncate text-base font-extrabold leading-tight text-foreground">Grand University</span>
        <span className="block truncate text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">UGC • NAAC A+ • AICTE</span>
      </span>
    </a>
  );
}

function PartnerLogo() {
  return (
    <div className="hidden min-w-0 items-center gap-2 sm:flex">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-secondary text-secondary-foreground">
        <Sparkles className="h-4 w-4" />
      </span>
      <span className="min-w-0">
        <span className="block text-xs font-bold leading-tight text-foreground">EduPrime</span>
        <span className="block text-[10px] text-muted-foreground">Authorised Partner</span>
      </span>
    </div>
  );
}

/* ---------- HERO ---------- */
function Hero() {
  return (
    <section className="relative overflow-hidden bg-[linear-gradient(135deg,#1f1b2e_0%,#2a2440_55%,#3a2f55_100%)]">
      {/* decorative glows */}
      <div className="pointer-events-none absolute -left-32 top-10 h-96 w-96 rounded-full bg-[#ef4444]/20 blur-3xl" aria-hidden />
      <div className="pointer-events-none absolute -right-32 bottom-0 h-96 w-96 rounded-full bg-[#a855f7]/20 blur-3xl" aria-hidden />

      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-10 sm:px-6 sm:py-16 lg:grid-cols-[1.05fr_1fr_0.9fr] lg:gap-8 lg:py-20 lg:px-8">
        {/* LEFT — copy */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-white lg:col-span-1"
        >
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold backdrop-blur ring-1 ring-white/20">
            <span className="h-2 w-2 animate-pulse rounded-full bg-[#ef4444]" />
            UGC Approved · Admissions Open 2026
          </span>
          <h1 className="mt-5 text-4xl font-black leading-[1.02] sm:text-5xl xl:text-[3.5rem]">
            NMIMS ONLINE
            <span className="mt-1 block bg-[linear-gradient(135deg,#ef4444,#f97316)] bg-clip-text text-transparent">
              MBA | BBA | BCOM
            </span>
          </h1>
          <p className="mt-4 text-xl font-bold text-white/95">One Degree, Unlimited Opportunities</p>
          <p className="mt-3 max-w-xl text-sm text-white/75 sm:text-base">
            Advance your career with NMIMS Online — offering UGC Approved Online MBA, Online BBA & Online BCom programs for students, freshers and working professionals across INDIA.
          </p>

          <ul className="mt-6 grid max-w-lg gap-2.5 sm:grid-cols-2">
            {[
              { icon: Video, t: "Live Interactive Lectures" },
              { icon: ShieldCheck, t: "UGC Approved Degree" },
              { icon: Briefcase, t: "Placement Assistance" },
              { icon: Clock, t: "Flexible Learning" },
            ].map(({ icon: Icon, t }) => (
              <li key={t} className="flex items-center gap-2.5 text-sm font-semibold text-white/95">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#ef4444]/20 ring-1 ring-[#ef4444]/40">
                  <Icon className="h-3.5 w-3.5 text-[#fca5a5]" />
                </span>
                {t}
              </li>
            ))}
          </ul>

          <div className="mt-7 flex flex-wrap gap-3">
            <a
              href={telLink}
              className="inline-flex items-center gap-2 rounded-full bg-[linear-gradient(135deg,#ef4444,#dc2626)] px-6 py-3 text-sm font-bold text-white shadow-[0_12px_30px_-10px_rgba(239,68,68,0.7)] transition hover:scale-[1.03]"
            >
              <Phone className="h-4 w-4" /> Call Now
            </a>
            <a
              href={waLink}
              target="_blank" rel="noopener"
              className="inline-flex items-center gap-2 rounded-full bg-[#25d366] px-6 py-3 text-sm font-bold text-white shadow-[0_12px_30px_-10px_rgba(37,211,102,0.7)] transition hover:scale-[1.03]"
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
          </div>
        </motion.div>

        {/* MIDDLE — student visual */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="relative mx-auto hidden h-[460px] w-full max-w-sm lg:block"
        >
          {/* gold orbit ring */}
          <div className="absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-dashed border-[#fbbf24]/40" />
          {/* orange blob */}
          <div className="absolute left-1/2 top-1/2 h-[340px] w-[340px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[linear-gradient(135deg,#f97316,#ef4444)] shadow-[0_30px_80px_-20px_rgba(239,68,68,0.6)]" />
          {/* student photo */}
          <img
            src={heroStudent}
            alt="NMIMS Online student"
            className="absolute left-1/2 top-1/2 h-[440px] w-[330px] -translate-x-1/2 -translate-y-1/2 rounded-[180px] object-cover"
          />

          {/* Floating label TOP */}
          <motion.div
            initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 }}
            className="absolute left-0 top-6 rounded-2xl bg-white/95 px-4 py-2.5 shadow-elegant backdrop-blur"
          >
            <p className="text-[10px] font-bold uppercase tracking-wider text-[#ef4444]">Live Interactive</p>
            <p className="text-sm font-extrabold text-foreground">Lectures</p>
          </motion.div>

          {/* Floating label BOTTOM */}
          <motion.div
            initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.75 }}
            className="absolute bottom-8 right-0 rounded-2xl bg-white/95 px-4 py-2.5 shadow-elegant backdrop-blur"
          >
            <p className="text-[10px] font-bold uppercase tracking-wider text-[#ef4444]">Study</p>
            <p className="text-sm font-extrabold text-foreground">anytime, anywhere</p>
          </motion.div>

          {/* small star badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.9 }}
            className="absolute right-6 top-16 grid h-12 w-12 place-items-center rounded-full bg-[#fbbf24] shadow-elegant"
          >
            <Star className="h-5 w-5 fill-white text-white" />
          </motion.div>
        </motion.div>

        {/* RIGHT — form */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="lg:col-span-1"
        >
          <EnquiryForm />
        </motion.div>
      </div>

      {/* trust strip */}
      <div className="relative border-t border-white/10 bg-black/20 py-4 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-6 gap-y-2 px-4 text-xs font-semibold text-white/80 sm:gap-x-10 sm:text-sm">
          <span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-[#fbbf24]" /> UGC Approved</span>
          <span className="flex items-center gap-2"><Award className="h-4 w-4 text-[#fbbf24]" /> NAAC A++</span>
          <span className="flex items-center gap-2"><Star className="h-4 w-4 fill-[#fbbf24] text-[#fbbf24]" /> 4.8/5 · 12,000+ learners</span>
          <span className="flex items-center gap-2"><Globe2 className="h-4 w-4 text-[#fbbf24]" /> 200+ cities across India</span>
        </div>
      </div>
    </section>
  );
}

/* ---------- CAREER GROWTH ---------- */
function CareerGrowth() {
  const items = [
    { icon: TrendingUp, t: "Career Growth", d: "Average 60% salary hike reported by graduates within 12 months." },
    { icon: Award, t: "Industry Recognition", d: "Degree recognised by leading employers and government bodies." },
    { icon: Clock, t: "Flexible Learning", d: "Study evenings & weekends without pausing your career." },
    { icon: Sparkles, t: "Skill Development", d: "Industry-aligned electives, projects and capstone with mentors." },
  ];
  return (
    <section className="bg-surface-soft py-16 sm:py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-8">
        <motion.div
          initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
          className="relative"
        >
          <div className="absolute -inset-4 rounded-3xl gradient-primary opacity-20 blur-2xl" aria-hidden />
          <img src={careerImg} alt="Career growth" loading="lazy" className="relative rounded-3xl shadow-elegant" width={1200} height={1200} />
          <div className="absolute -bottom-6 -right-4 rounded-2xl bg-card p-4 shadow-elegant sm:-right-6">
            <div className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-xl gradient-gold">
                <TrendingUp className="h-5 w-5 text-accent-foreground" />
              </span>
              <div>
                <p className="text-2xl font-extrabold text-foreground">+60%</p>
                <p className="text-xs text-muted-foreground">Avg. salary growth</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
        >
          <span className="text-xs font-bold uppercase tracking-widest text-primary">Why upgrade now</span>
          <h2 className="mt-2 text-3xl font-extrabold text-foreground sm:text-4xl lg:text-5xl">
            Elevate Your <span className="text-gradient">Career</span>
          </h2>
          <p className="mt-3 max-w-lg text-base text-muted-foreground">
            A globally recognised degree from a top-ranked Indian university — designed for working professionals who want measurable growth.
          </p>
          <ul className="mt-8 grid gap-4 sm:grid-cols-2">
            {items.map(({ icon: Icon, t, d }) => (
              <li key={t} className="rounded-2xl border border-border bg-card p-5 shadow-card transition hover:-translate-y-1 hover:shadow-elegant">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl gradient-primary text-primary-foreground">
                  <Icon className="h-4 w-4" />
                </span>
                <h3 className="mt-3 text-base font-bold text-foreground">{t}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{d}</p>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </section>
  );
}

/* ---------- GALLERY ---------- */
function Gallery() {
  const imgs = [
    { src: gCampus, label: "Campus" },
    { src: gClass, label: "Classrooms" },
    { src: gEvents, label: "Events" },
    { src: gStudents, label: "Students" },
    { src: gFacilities, label: "Facilities" },
  ];
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionTitle eyebrow="Inside the university" title="A campus built for ambition" />
        <div className="mt-10 -mx-4 flex gap-4 overflow-x-auto px-4 hide-scrollbar sm:gap-6">
          {imgs.map((i, idx) => (
            <motion.figure
              key={i.label}
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: idx * 0.05 }}
              className="group relative shrink-0 overflow-hidden rounded-3xl shadow-card"
              style={{ width: "min(80vw, 380px)", aspectRatio: "4/3" }}
            >
              <img src={i.src} alt={i.label} loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent p-4 text-sm font-bold text-white">
                {i.label}
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- PROGRAMS ---------- */
function Programs() {
  const list = [
    { icon: Briefcase, name: "Online MBA", dur: "2 Years", high: ["10+ specialisations", "Live mentor sessions", "Industry capstone"] },
    { icon: Laptop, name: "Online MCA", dur: "2 Years", high: ["Cloud & AI track", "Hands-on labs", "GitHub projects"] },
    { icon: BookOpen, name: "Online BBA", dur: "3 Years", high: ["Business fundamentals", "Internship support", "Soft-skills bootcamp"] },
    { icon: Cpu, name: "Online BCA", dur: "3 Years", high: ["Full-stack curriculum", "Coding mentorship", "Placement drives"] },
    { icon: Calculator, name: "Online M.Com", dur: "2 Years", high: ["Finance & taxation", "ESG accounting", "CA-aligned"] },
    { icon: Award, name: "PG Diploma", dur: "1 Year", high: ["Fast-track upskill", "Industry certificates", "Project portfolio"] },
  ];
  return (
    <section className="bg-surface-soft py-16 sm:py-24" id="programs">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionTitle eyebrow="Explore programs" title="UGC-entitled degrees designed for working professionals" />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map(({ icon: Icon, name, dur, high }, i) => (
            <motion.article
              key={name}
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.04 }}
              className="group relative overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-card transition hover:-translate-y-1 hover:shadow-elegant"
            >
              <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full gradient-primary opacity-10 blur-2xl transition group-hover:opacity-20" />
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl gradient-primary text-primary-foreground shadow-card">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-xl font-extrabold text-foreground">{name}</h3>
              <p className="mt-1 inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                <Clock className="h-3.5 w-3.5" /> Duration: {dur}
              </p>
              <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                {high.map((h) => (
                  <li key={h} className="flex gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[color:var(--gold)]" />
                    {h}
                  </li>
                ))}
              </ul>
              <a href="#enquire" className="mt-6 inline-flex items-center gap-1 text-sm font-bold text-primary transition group-hover:gap-2">
                Get Curriculum <ArrowRight className="h-4 w-4" />
              </a>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- SPECIALIZATIONS ---------- */
function Specializations() {
  const items = [
    { icon: Megaphone, t: "Marketing" },
    { icon: BarChart3, t: "Finance" },
    { icon: UserCog, t: "Human Resources" },
    { icon: TrendingUp, t: "Business Analytics" },
    { icon: Building2, t: "Operations" },
    { icon: Cpu, t: "IT Management" },
  ];
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionTitle eyebrow="MBA Specializations" title="Choose a track that matches your ambition" />
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {items.map(({ icon: Icon, t }, i) => (
            <motion.div
              key={t}
              initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
              className="group flex flex-col items-center rounded-2xl border border-border bg-card p-5 text-center shadow-card transition hover:-translate-y-1 hover:border-primary hover:shadow-elegant"
            >
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-secondary text-primary transition group-hover:gradient-primary group-hover:text-primary-foreground">
                <Icon className="h-5 w-5" />
              </span>
              <p className="mt-3 text-sm font-bold text-foreground">{t}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- WHY CHOOSE ---------- */
function WhyChoose() {
  const items = [
    { icon: Video, t: "Live Interactive Classes", d: "Weekend live sessions with award-winning faculty and real-time Q&A." },
    { icon: Laptop, t: "Recorded Sessions", d: "Lifetime access to high-quality recordings — learn at your pace." },
    { icon: GraduationCap, t: "Experienced Faculty", d: "Learn from IIM, IIT and industry leaders with 15+ years experience." },
    { icon: Briefcase, t: "Placement Assistance", d: "1:1 career coaching, resume review and access to 700+ hiring partners." },
    { icon: Clock, t: "Flexible Learning", d: "Study evenings & weekends without putting your career on hold." },
    { icon: Headphones, t: "24×7 Student Support", d: "Dedicated mentors, doubt-solving and academic guidance whenever you need." },
  ];
  return (
    <section className="bg-surface-soft py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionTitle eyebrow="Why students choose us" title="Everything you need to succeed, in one place" />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map(({ icon: Icon, t, d }, i) => (
            <motion.div
              key={t}
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
              className="rounded-3xl border border-border bg-card p-6 shadow-card transition hover:-translate-y-1 hover:shadow-elegant"
            >
              <span className="grid h-12 w-12 place-items-center rounded-2xl gradient-primary text-primary-foreground shadow-card">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-lg font-extrabold text-foreground">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- COUNTERS ---------- */
function Counters() {
  const items = [
    { n: 75000, s: "+", l: "Students Enrolled" },
    { n: 120000, s: "+", l: "Strong Alumni Network" },
    { n: 700, s: "+", l: "Hiring Partners" },
    { n: 60, s: "%", l: "Avg. Career Growth" },
  ];
  return (
    <section className="relative overflow-hidden bg-foreground py-16 text-white sm:py-20">
      <div className="absolute -left-20 top-0 h-72 w-72 rounded-full bg-primary opacity-30 blur-3xl" aria-hidden />
      <div className="absolute -right-20 bottom-0 h-72 w-72 rounded-full bg-[color:var(--gold)] opacity-20 blur-3xl" aria-hidden />
      <div className="relative mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 sm:px-6 lg:grid-cols-4 lg:px-8">
        {items.map(({ n, s, l }) => (
          <div key={l} className="text-center">
            <p className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
              <Counter to={n} suffix={s} />
            </p>
            <p className="mt-2 text-xs font-semibold uppercase tracking-widest text-white/70 sm:text-sm">{l}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- CAMPUS / UNIVERSITY ---------- */
function CampusSection() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <motion.img
          src={universityImg} alt="University campus" loading="lazy" width={1600} height={1000}
          initial={{ opacity: 0, scale: 0.97 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.7 }}
          className="rounded-3xl shadow-elegant"
        />
        <div>
          <SectionTitle align="left" eyebrow="The University" title="A legacy of excellence, recognised globally" />
          <p className="mt-4 text-muted-foreground">
            Established in 1981, Grand University is one of India's most reputed multi-disciplinary universities, with a sprawling campus and a tradition of academic excellence.
          </p>
          <div className="mt-6 flex items-start gap-3 rounded-2xl bg-secondary p-4">
            <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <p className="text-sm text-foreground">
              <strong className="font-bold">Main Campus:</strong> University Road, Knowledge Park, Bengaluru — 560100, Karnataka, India
            </p>
          </div>
          <div className="mt-6">
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Accreditations & Recognition</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["UGC-DEB Entitled", "NAAC A+", "AICTE Approved", "AIU Member", "NBA Accredited", "WES Recognised"].map((b) => (
                <span key={b} className="rounded-xl border border-border bg-card px-3 py-2 text-xs font-bold text-foreground shadow-card">
                  ✓ {b}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- TESTIMONIALS ---------- */
function Testimonials() {
  const items = [
    { img: t1, name: "Rohit Sharma", program: "Online MBA — Marketing", quote: "The live mentor sessions changed how I approach my role. I got promoted to Marketing Manager within 8 months of joining the program." },
    { img: t2, name: "Priya Menon", program: "Online MCA", quote: "Flexible classes meant I could keep my full-time job. The placement cell helped me move into a senior developer role with a 70% hike." },
    { img: t3, name: "Amit Kulkarni", program: "Online MBA — Finance", quote: "Faculty quality is on par with top B-schools. The capstone project gave me confidence to lead my own FP&A team." },
  ];
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx((i) => (i + 1) % items.length), 6000);
    return () => clearInterval(t);
  }, [items.length]);
  return (
    <section className="bg-surface-soft py-16 sm:py-24">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionTitle eyebrow="Student stories" title="Real outcomes from real learners" />
        <div className="mt-12 relative">
          {items.map((it, i) => (
            <motion.div
              key={i}
              initial={false}
              animate={{ opacity: idx === i ? 1 : 0, x: idx === i ? 0 : 30, position: idx === i ? "relative" : "absolute" }}
              transition={{ duration: 0.5 }}
              className="inset-0 grid items-center gap-8 rounded-3xl bg-card p-6 shadow-elegant sm:p-10 lg:grid-cols-[auto_1fr] lg:gap-12"
              style={{ display: idx === i ? "grid" : "none" }}
            >
              <img src={it.img} alt={it.name} loading="lazy" width={512} height={512} className="mx-auto h-28 w-28 rounded-full object-cover shadow-card ring-4 ring-[color:var(--gold)]/40 sm:h-36 sm:w-36 lg:mx-0" />
              <div>
                <div className="flex gap-1 text-[color:var(--gold)]">
                  {Array.from({ length: 5 }).map((_, k) => <Star key={k} className="h-4 w-4 fill-current" />)}
                </div>
                <blockquote className="mt-3 text-lg font-medium leading-relaxed text-foreground sm:text-xl">
                  "{it.quote}"
                </blockquote>
                <p className="mt-4 font-extrabold text-foreground">{it.name}</p>
                <p className="text-sm text-muted-foreground">{it.program}</p>
              </div>
            </motion.div>
          ))}
          <div className="mt-6 flex justify-center gap-2">
            {items.map((_, i) => (
              <button
                key={i}
                aria-label={`Show testimonial ${i + 1}`}
                onClick={() => setIdx(i)}
                className={`h-2 rounded-full transition-all ${idx === i ? "w-8 gradient-primary" : "w-2 bg-border"}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- FAQ ---------- */
function FAQ() {
  const items = [
    { q: "Who is eligible for the online programs?", a: "Eligibility varies by program. Generally, UG programs require 10+2 from a recognised board; PG programs require a recognised bachelor's degree with 50% marks (45% for reserved categories)." },
    { q: "What is the fee structure and are EMIs available?", a: "Program fees start from ₹85,000 per year. Easy 0% interest EMI options up to 24 months are available, along with scholarships for early applicants." },
    { q: "How does the admission process work?", a: "1) Submit enquiry · 2) Counselling call · 3) Online application · 4) Document upload · 5) Fee payment & enrollment. Most admissions are confirmed within 48–72 hours." },
    { q: "Do you provide placement support?", a: "Yes. Our placement cell offers 1:1 career coaching, resume reviews, mock interviews and access to a network of 700+ hiring partners across India and abroad." },
    { q: "What is the program duration and validity?", a: "UG programs are 3 years (max 6), PG programs are 2 years (max 4). All degrees are UGC-DEB entitled and equivalent to on-campus degrees." },
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="py-16 sm:py-24" id="faq">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <SectionTitle eyebrow="Frequently Asked Questions" title="Everything you need to know" />
        <div className="mt-10 space-y-3">
          {items.map((it, i) => (
            <div key={i} className="overflow-hidden rounded-2xl border border-border bg-card shadow-card">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between gap-4 p-5 text-left"
                aria-expanded={open === i}
              >
                <span className="font-bold text-foreground">{it.q}</span>
                <ChevronDown className={`h-5 w-5 shrink-0 text-primary transition-transform ${open === i ? "rotate-180" : ""}`} />
              </button>
              <motion.div
                initial={false}
                animate={{ height: open === i ? "auto" : 0, opacity: open === i ? 1 : 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <p className="px-5 pb-5 text-sm leading-relaxed text-muted-foreground">{it.a}</p>
              </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- FINAL CTA ---------- */
function FinalCTA() {
  return (
    <section className="px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2rem] gradient-primary p-8 text-center shadow-elegant sm:p-16">
        <div className="absolute -left-20 -top-20 h-60 w-60 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -right-20 -bottom-20 h-60 w-60 rounded-full bg-[color:var(--gold)]/30 blur-3xl" />
        <span className="relative inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-xs font-bold text-white ring-1 ring-white/30">
          <Sparkles className="h-3.5 w-3.5" /> Limited seats — last 7 days
        </span>
        <h2 className="relative mt-5 text-4xl font-extrabold leading-tight text-white sm:text-5xl lg:text-6xl">
          Admissions Open
        </h2>
        <p className="relative mx-auto mt-4 max-w-2xl text-white/90 sm:text-lg">
          Join 75,000+ ambitious learners. Start your UGC-entitled online degree today and unlock the career you deserve.
        </p>
        <div className="relative mt-8 flex flex-wrap justify-center gap-3">
          <a href="#enquire" className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-bold text-primary shadow-elegant transition hover:scale-[1.03]">
            Apply Now <ArrowRight className="h-4 w-4" />
          </a>
          <a href={telLink} className="inline-flex items-center gap-2 rounded-xl bg-foreground/30 px-6 py-3.5 text-sm font-bold text-white ring-1 ring-white/30 backdrop-blur transition hover:bg-foreground/40">
            <Phone className="h-4 w-4" /> Call Now
          </a>
          <a href={waLink} target="_blank" rel="noopener" className="inline-flex items-center gap-2 rounded-xl bg-[color:var(--whatsapp)] px-6 py-3.5 text-sm font-bold text-white shadow-elegant transition hover:scale-[1.03]">
            <MessageCircle className="h-4 w-4" /> WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}

/* ---------- FOOTER ---------- */
function Footer() {
  return (
    <footer className="bg-foreground pb-28 pt-16 text-white/80 sm:pb-16">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2">
            <span className="grid h-10 w-10 place-items-center rounded-xl gradient-gold">
              <GraduationCap className="h-5 w-5 text-accent-foreground" />
            </span>
            <div>
              <p className="font-extrabold text-white">EduPrime</p>
              <p className="text-xs">Authorised Admission Partner</p>
            </div>
          </div>
          <p className="mt-4 max-w-md text-sm">
            EduPrime is an authorised admission partner empanelled with India's top-ranked universities for their UGC-DEB entitled online programs.
          </p>
          <div className="mt-5 space-y-2 text-sm">
            <p className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold)]" /> EduPrime HQ, Tower B, Cyber City, Bengaluru 560100, India</p>
            <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-[color:var(--gold)]" /> {PHONE}</p>
            <p className="flex items-center gap-2"><Mail className="h-4 w-4 text-[color:var(--gold)]" /> admissions@eduprime.in</p>
          </div>
        </div>
        <div>
          <p className="text-sm font-bold text-white">Programs</p>
          <ul className="mt-3 space-y-2 text-sm">
            {["Online MBA", "Online MCA", "Online BBA", "Online BCA", "Online M.Com"].map(p => (
              <li key={p}><a href="#programs" className="hover:text-[color:var(--gold)]">{p}</a></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-sm font-bold text-white">Legal</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li><a href="#" className="hover:text-[color:var(--gold)]">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-[color:var(--gold)]">Terms of Service</a></li>
            <li><a href="#" className="hover:text-[color:var(--gold)]">Disclaimer</a></li>
            <li><a href="#" className="hover:text-[color:var(--gold)]">Refund Policy</a></li>
          </ul>
        </div>
      </div>
      <div className="mx-auto mt-12 max-w-7xl border-t border-white/10 px-4 pt-6 text-xs text-white/60 sm:px-6 lg:px-8">
        <p className="mb-2">
          <strong className="text-white/80">Disclaimer:</strong> EduPrime is an authorised admission partner and not the university itself. All academic delivery, certification and degrees are awarded by the respective university. Brand names and logos used are property of their respective owners.
        </p>
        <p>© {new Date().getFullYear()} EduPrime Education Services Pvt. Ltd. All rights reserved.</p>
      </div>
    </footer>
  );
}

/* ---------- FLOATING / STICKY ---------- */
function FloatingWA() {
  return (
    <a
      href={waLink} target="_blank" rel="noopener" aria-label="Chat on WhatsApp"
      className="fixed bottom-24 right-4 z-40 grid h-14 w-14 place-items-center rounded-full bg-[color:var(--whatsapp)] text-white shadow-elegant transition hover:scale-110 sm:bottom-6 sm:right-6"
    >
      <span className="absolute inset-0 animate-ping rounded-full bg-[color:var(--whatsapp)] opacity-30" />
      <MessageCircle className="relative h-6 w-6" />
    </a>
  );
}

function MobileCTABar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-3 gap-2 border-t border-border bg-card/95 p-3 shadow-elegant backdrop-blur sm:hidden">
      <a href={telLink} className="flex items-center justify-center gap-1.5 rounded-xl border border-border bg-card py-3 text-xs font-bold text-foreground">
        <Phone className="h-4 w-4" /> Call
      </a>
      <a href={waLink} target="_blank" rel="noopener" className="flex items-center justify-center gap-1.5 rounded-xl bg-[color:var(--whatsapp)] py-3 text-xs font-bold text-white">
        <MessageCircle className="h-4 w-4" /> WhatsApp
      </a>
      <a href="#enquire" className="flex items-center justify-center gap-1.5 rounded-xl gradient-primary py-3 text-xs font-bold text-primary-foreground">
        Enquire <ArrowRight className="h-4 w-4" />
      </a>
    </div>
  );
}

/* ---------- shared ---------- */
function SectionTitle({ eyebrow, title, align = "center" }: { eyebrow: string; title: string; align?: "center" | "left" }) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-xl"}>
      <span className="text-xs font-bold uppercase tracking-widest text-primary">{eyebrow}</span>
      <h2 className="mt-2 text-3xl font-extrabold text-foreground sm:text-4xl lg:text-5xl">{title}</h2>
    </div>
  );
}
